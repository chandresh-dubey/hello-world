<?php

namespace Chatter\Models;

class Message extends \Illuminate\Database\Eloquent\Model
{
  
}

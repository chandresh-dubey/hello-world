# slim-rest-api
A RESTful API with Slim Framework

Une API Restful utilisant Slim Framework de PHP.

Pour une bonne documentation, veuillez consulter sur ce lien [http://code.koffisani.ga/api/2017/01/27/chatter-rest-api.html](http://code.koffisani.ga/api/2017/01/27/chatter-rest-api.html) ou [ici](https://github.com/koffisani/slim-rest-api/wiki) 

---
title: Our support forum now uses Tender
description: The Slim Framework for PHP 5 support forum now runs on Tender
layout: post
---

I am happy to announce that Slim’s support forum and knowledge base now run on Tender™. We previously used the Vanilla forum software, but it proved unstable and unreliable for many users. I want to extend a big thank you to Tender for setting up an open source account for us. Our initial impression is that it is a phenomenal platform, and we cannot wait to put it to good use.

If you have questions about how something in Slim works, or if you run into a problem, open a new discussion at <http://help.slimframework.com/> and our support team (just me at the moment) will try to help you as best we can.

The new support forum is also a great place for you to help others and share your work. If you have a cool project you built with Slim, definitely show it off in the forum. We’d love to see and promote what you’ve done with Slim.

If you run a business of your own and need a support forum, I highly recommend Tender™; it seems like a brilliant platform, and I know first-hand that the folks on its support team are top notch.

[Visit Our Support Forum](http://help.slimframework.com/)

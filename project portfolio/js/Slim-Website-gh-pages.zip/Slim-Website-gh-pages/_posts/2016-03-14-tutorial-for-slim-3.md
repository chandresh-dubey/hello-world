---
title: First Application Walkthrough Tutorial
description: First Application Walkthrough Tutorial
layout: post
---

We are very happy to have added our first Slim 3 tutorial to the documentation!
Contributed by [Lorna Mitchell](http://www.lornajane.net),
[First Application Walkthrough](/docs/tutorial/first-app.html) guides you through
building your first application with Slim Framework.


It covers everything you need to get started, from installation and
configuration through to dealing with databases and logging, creating
routes and the relevant view scripts along the way. Once you have gone through
this tutorial, you'll have a good grounding in how Slim works.

---
title: Slim 3 Primer by Rob Allen
description: Learn what's new in Slim 3.0
layout: post
---

[Rob Allen](http://akrabat.com/) presents a primer on Slim 3.0 at a recent PHPSW meetup. Watch the video at <http://phpsw.uk/talks/a-slim-3-primer>.

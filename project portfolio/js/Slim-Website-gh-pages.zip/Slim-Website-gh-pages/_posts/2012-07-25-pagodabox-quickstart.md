---
title: Launch apps on PagodaBox with the Slim Framework Quickstart
description: Use the official Slim Framework quickstart to instantly launch Slim Framework applications on the PagodaBox platform.
layout: post
---

Now you can instantly launch new Slim Framework applications on PagodaBox with the official Slim Framework quickstart. You don’t have to worry about creating filesystem directories, downloading and installing the Slim Framework libraries, or messing with complicated deployment routines.

It’s super simple to get started: visit the URL below and click “Launch”.

<https://pagodabox.com/cafe/codeguy/slim>

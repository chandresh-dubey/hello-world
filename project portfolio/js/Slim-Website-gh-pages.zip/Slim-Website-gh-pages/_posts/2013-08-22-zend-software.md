---
title: Slim Framework and Zend Server Enterprise Edition
description: Top 50 Slim Framework contributors eligible for Zend Server Enterprise Edition and Zend Studio
layout: post
---

The top 50 Slim Framework contributors are eligible for a free copy of
[Zend Server Enterprise Edition](http://www.zend.com/en/products/server/) and [Zend Studio](http://www.zend.com/en/products/studio/) — together worth over $10,000. According to Zend, they “are fully supported and can be used for production on a single server.” Visit <http://updates.zend.com/lp/> for more information.

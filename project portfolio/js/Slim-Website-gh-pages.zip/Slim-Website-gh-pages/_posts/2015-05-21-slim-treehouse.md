---
title: Treehouse Slim Framework Tutorials
description: Treehouse has published a new tutorial series on the Slim Framework.
layout: post
---

[Treehouse](http://teamtreehouse.com/) and [Hampton Paulk](http://teamtreehouse.com/hamptonpaulk) have published a new tutorial series that demonstrates how to create a website with the Slim Framework. It's aimed at PHP beginners, and it teaches you how to use Composer, Slim, SwiftMailer, and Monolog while building a simple website.

<http://teamtreehouse.com/library/building-websites-with-php>

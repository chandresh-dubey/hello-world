---
title: We're getting ready to start work on Slim Framework v4.0
description: We're getting ready to start work on Slim Framework v4.0
layout: post
---

We are happy to announce that we will soon start work on Slim Framework version 4.0. You can see our project road map on our [GitHub issue tracker](https://github.com/slimphp/Slim/issues?q=is%3Aopen+is%3Aissue+milestone%3A4.0).

I wanted to extend a big thank you to Rob Allen, Andrew Smith, and all of Slim's contributors who have helped keep the project moving along while I've been focused elsewhere. I am happy to announce that I'm finally available to contribute more of my time to Slim again. I look forward to working with Rob, Andrew, and the rest of the Slim Framework contributors to make a big push toward version 4.0!

If you have any questions, or if you would like to help work on version 4.0, please reach out via the GitHub issue tracker or on [Slim's Slack channel](https://www.slimframework.com/#community).

Thank you,

Josh

--
Josh Lockhart  
Founder, Slim Framework  
http://slimframework.com


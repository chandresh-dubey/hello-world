---
title: Mentioned in .NET Magazine
description: The Slim Framework for PHP 5 was mentioned by Lorna Jane in her opinion piece for .NET magazine
layout: post
---

Today Slim was mentioned by [Lorna Mitchell](http://www.twitter.com/lornajane) in her latest opinion piece for [.NET Magazine](http://www.netmagazine.com/) that analyzes the current landscape of PHP frameworks. Head on over to read her article, [Land of a Thousand Frameworks](http://www.netmagazine.com/opinions/php-land-thousand-frameworks).

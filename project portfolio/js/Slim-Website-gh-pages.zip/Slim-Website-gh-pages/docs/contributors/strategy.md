---
title: Branching Strategy
---

The Slim Framework uses a simple branching strategy. There is a `3.x` branch, and the `3.x` branch `HEAD` reference points to the latest unstable code. Each stable release is denoted with a numeric tag (e.g., `3.0.0`).
